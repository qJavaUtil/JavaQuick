package test.util;

/**
 * @Author: Zhang.Jialei
 * @Date: 2020/12/6 16:19
 */
public class MyClassLoader extends ClassLoader{
}
