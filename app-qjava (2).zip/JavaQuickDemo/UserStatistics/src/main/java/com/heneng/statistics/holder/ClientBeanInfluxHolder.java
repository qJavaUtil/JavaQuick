package com.heneng.statistics.holder;

import blxt.qjava.autovalue.inter.Component;
import blxt.qjava.autovalue.inter.Configuration;
import blxt.qjava.autovalue.inter.Value;
import blxt.qjava.qsql.influxdb.InfluxConnection;
import blxt.qjava.qsql.influxdb.InfluxConnectionPool;
import com.heneng.statistics.model.ClientBean;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
@Component
@Configuration
public class ClientBeanInfluxHolder {

    @Value("influx.database")
    String dataBase;

    public void install(ClientBean bean){

        InfluxConnection connection = InfluxConnectionPool.getInstance().getInfluxConnection(dataBase, true);

        String measurement = "mqtt/statistics";
        Map<String, String> tags = new HashMap<>();
        Map<String, Object> fields = new HashMap<>();

        tags.put("AppTage", bean.getAppTage());
        tags.put("Hostname", bean.getHostname());

        fields.put("ips", bean.getIp());
        fields.put("rute_ips", bean.getRuteIp());
        fields.put("macs", bean.getMacs());

        connection.insert(measurement, tags, fields, 0, null);
    }
}
