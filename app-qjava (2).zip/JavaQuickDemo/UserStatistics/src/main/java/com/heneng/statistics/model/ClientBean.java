package com.heneng.statistics.model;

import lombok.Data;

@Data
public class ClientBean {
    String appTage;
    String ip;
    String macs;
    String hostname;
    String ruteIp; // 路由ip

    public ClientBean(){

    }

    public ClientBean(String appTage, String ip, String macs, String hostname, String ruteIp) {
        this.appTage = appTage;
        this.ip = ip;
        this.macs = macs;
        this.hostname = hostname;
        this.ruteIp = ruteIp;
    }
}
