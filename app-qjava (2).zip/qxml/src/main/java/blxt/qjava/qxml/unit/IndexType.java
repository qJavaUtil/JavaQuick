package blxt.qjava.qxml.unit;
 
/**
 * 坐标类型
 * @author MI
 *
 */
public class IndexType {
	public int index;
	public int type;
	
	public IndexType(int index, int type) {
		super();
		this.index = index;
		this.type = type;
	}
}