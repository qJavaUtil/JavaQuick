package model;

import lombok.Data;

@Data
public class TaskBean {
    public String time;
    public String key1;
    public String key2;
    public String value;
    public String value2;
}
