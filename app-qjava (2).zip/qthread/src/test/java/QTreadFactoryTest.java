import blxt.qjava.qthread.QTreadFactory;
import org.junit.Test;

/**
 * @Author: Zhang.Jialei
 * @Date: 2020/10/12 10:14
 */
public class QTreadFactoryTest {

    @Test
    public void test(){
        QTreadFactory.creatDefaultPool();
    }
}
