package blxt.qjava.qftp;

/** ftp权限
 */
public enum FtpPermission {
    READ, WRITE, READ_ADN_WRITE
}
