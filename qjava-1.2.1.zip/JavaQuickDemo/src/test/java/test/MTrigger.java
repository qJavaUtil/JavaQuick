package test;

public class MTrigger {
}
