package test.model.taks;

public class AutoTask {
}
