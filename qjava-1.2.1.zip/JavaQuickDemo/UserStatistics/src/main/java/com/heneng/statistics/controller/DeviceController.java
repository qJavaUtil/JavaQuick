package com.heneng.statistics.controller;

import blxt.qjava.autovalue.autoload.AutoRestController;
import blxt.qjava.autovalue.inter.Autowired;
import blxt.qjava.autovalue.inter.Component;
import blxt.qjava.autovalue.inter.RequestMapping;
import blxt.qjava.autovalue.inter.RequestMethod;
import com.alibaba.fastjson.JSON;
import com.heneng.statistics.holder.ClientBeanInfluxHolder;
import com.heneng.statistics.model.ClientBean;
import com.sun.net.httpserver.HttpExchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @Author: Zhang.Jialei
 * @Date: 2020/8/5 10:05
 */
@Component
@RequestMapping("/mqtt")
public class DeviceController {
    static Logger logger = LoggerFactory.getLogger(DeviceController.class);

    @Autowired
    ClientBeanInfluxHolder clientBeanInfluxDao;

    @RequestMapping(value="/hello",method= RequestMethod.POST)
    public String hello() {
        return "hello";
    }

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public String insert(HttpExchange request,
                         String appTage,
                         String ip,
                         String macs,
                         String hostname) {

        // 远端Ip
        String remoteIp = request.getRemoteAddress().getHostString();
        ClientBean bean = new ClientBean(appTage, ip, macs, hostname, null);
        bean.setRuteIp(remoteIp);
        logger.debug("注册信息:{}", JSON.toJSONString(bean));
        clientBeanInfluxDao.install(bean);
        return "success";
    }

}
