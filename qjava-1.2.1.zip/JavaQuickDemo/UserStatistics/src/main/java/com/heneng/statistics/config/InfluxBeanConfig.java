package com.heneng.statistics.config;

import blxt.qjava.autovalue.inter.Bean;
import blxt.qjava.autovalue.inter.Component;
import blxt.qjava.autovalue.util.ValueFactory;
import blxt.qjava.qsql.influxdb.InfluxBean;
import blxt.qjava.qsql.influxdb.InfluxConnectionPool;

@Component
public class InfluxBeanConfig {

    @Bean
    public InfluxBean initInfluxBean(){
        ValueFactory valueFactory = new ValueFactory();
        InfluxBean bean = valueFactory.autoVariable(InfluxBean.class);
        InfluxConnectionPool.newInstance(bean);
        return bean;
    }
}
