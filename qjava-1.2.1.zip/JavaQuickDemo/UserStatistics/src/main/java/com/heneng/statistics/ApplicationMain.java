package com.heneng.statistics;

import blxt.qjava.autovalue.QJavaApplication;
import blxt.qjava.autovalue.inter.EnHttpServer;

@EnHttpServer
public class ApplicationMain {

    public static void main(String[] args) throws Exception {
        QJavaApplication.run(ApplicationMain.class);
        System.out.println("加载完成");
    }


}

