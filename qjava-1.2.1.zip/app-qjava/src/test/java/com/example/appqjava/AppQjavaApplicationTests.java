package com.example.appqjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppQjavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
